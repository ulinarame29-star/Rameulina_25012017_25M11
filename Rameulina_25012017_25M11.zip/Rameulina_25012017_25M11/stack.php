<?php
session_start();
if (!isset($_SESSION['stack_data'])) $_SESSION['stack_data']=["Buku A","Buku B","Buku C"];
if(isset($_POST['push'])){
    $data=trim($_POST['data']??'');
    if($data!=='') $_SESSION['stack_data'][]=$data;
}
if(isset($_POST['pop']) && count($_SESSION['stack_data'])>0) array_pop($_SESSION['stack_data']);
if(isset($_POST['reset'])) $_SESSION['stack_data']=["Buku A","Buku B","Buku C"];
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stack</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<a href="index.php" class="back">← Kembali</a>
<h1>Struktur Data Stack</h1>
<p>Stack menggunakan prinsip LIFO (Last In, First Out).</p>
<form method="post" class="form">
<input type="text" name="data" placeholder="Masukkan data..." required>
<button type="submit" name="push">Push</button>
<button type="submit" name="pop">Pop</button>
<button type="submit" name="reset" class="danger">Reset</button>
</form>
<h2>Isi Stack</h2>
<div class="stack">
<?php if(count($_SESSION['stack_data'])===0): ?><div class="empty">Stack kosong</div>
<?php else: for($i=count($_SESSION['stack_data'])-1;$i>=0;$i--): ?>
<div class="stack-item"><?= htmlspecialchars($_SESSION['stack_data'][$i]) ?>
<?php if($i===count($_SESSION['stack_data'])-1): ?><span class="top">← TOP</span><?php endif; ?>
</div>
<?php endfor; endif; ?>
</div>
<div class="info"><h3>Cara Kerja</h3><p><b>Push</b> menambahkan data ke TOP. <b>Pop</b> menghapus data paling atas terlebih dahulu.</p></div>
</div></body></html>