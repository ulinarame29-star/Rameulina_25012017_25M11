<?php
session_start();
if (!isset($_SESSION['array_data'])) $_SESSION['array_data'] = ["Data 1","Data 2","Data 3"];

if (isset($_POST['tambah'])) {
    $data = trim($_POST['data'] ?? '');
    if ($data !== '') $_SESSION['array_data'][] = $data;
}
if (isset($_POST['hapus'])) {
    $index = (int)($_POST['index'] ?? -1);
    if (isset($_SESSION['array_data'][$index])) array_splice($_SESSION['array_data'], $index, 1);
}
if (isset($_POST['reset'])) $_SESSION['array_data'] = ["Data 1","Data 2","Data 3"];
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Array</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<a href="index.php" class="back">← Kembali</a>
<h1>Struktur Data Array</h1>
<p>Array menyimpan beberapa elemen dalam satu variabel dan setiap elemen mempunyai indeks.</p>
<form method="post" class="form">
<input type="text" name="data" placeholder="Masukkan data..." required>
<button type="submit" name="tambah">Tambah Data</button>
<button type="submit" name="reset" class="danger">Reset</button>
</form>
<h2>Isi Array</h2>
<div class="data-list">
<?php foreach ($_SESSION['array_data'] as $index=>$item): ?>
<div class="data-box"><strong>Index <?= $index ?></strong><span><?= htmlspecialchars($item) ?></span>
<form method="post"><input type="hidden" name="index" value="<?= $index ?>"><button type="submit" name="hapus" class="danger">Hapus</button></form>
</div>
<?php endforeach; ?>
</div>
<div class="info"><h3>Cara Kerja</h3><p>Tambah Data memasukkan elemen ke akhir array. Hapus menggunakan array_splice berdasarkan indeks.</p></div>
</div></body></html>