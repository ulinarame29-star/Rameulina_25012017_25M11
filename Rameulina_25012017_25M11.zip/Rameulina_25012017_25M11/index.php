<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Struktur Data Linear</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1>Project Struktur Data Linear</h1>
<p class="subtitle">Array, Linked List, dan Stack</p>
<div class="menu">
<a href="array.php" class="card"><h2>Array</h2><p>Menyimpan data secara berurutan menggunakan indeks.</p><span>Buka Halaman →</span></a>
<a href="linkedlist.php" class="card"><h2>Linked List</h2><p>Data disimpan dalam node yang saling terhubung.</p><span>Buka Halaman →</span></a>
<a href="stack.php" class="card"><h2>Stack</h2><p>Menggunakan konsep LIFO.</p><span>Buka Halaman →</span></a>
</div>
<div class="info"><h3>Konsep Singkat</h3>
<ul><li><b>Array:</b> elemen diakses menggunakan indeks.</li>
<li><b>Linked List:</b> setiap node menyimpan data dan referensi ke node berikutnya.</li>
<li><b>Stack:</b> menggunakan operasi push dan pop dengan prinsip LIFO.</li></ul></div>
</div>
</body>
</html>