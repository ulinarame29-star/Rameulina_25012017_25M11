<?php
session_start();

class Node {
    public $data;
    public $next;
    public function __construct($data) { $this->data=$data; $this->next=null; }
}
class LinkedList {
    public $head=null;
    public function add($data) {
        $newNode=new Node($data);
        if ($this->head===null) {$this->head=$newNode; return;}
        $current=$this->head;
        while ($current->next!==null) $current=$current->next;
        $current->next=$newNode;
    }
    public function delete($index) {
        if ($this->head===null) return;
        if ($index===0) {$this->head=$this->head->next; return;}
        $current=$this->head;
        for($i=0;$i<$index-1;$i++){if($current->next===null)return;$current=$current->next;}
        if($current->next!==null)$current->next=$current->next->next;
    }
}
if (!isset($_SESSION['linked_data'])) $_SESSION['linked_data']=["Node 1","Node 2","Node 3"];
if (isset($_POST['tambah'])) {
    $data=trim($_POST['data']??'');
    if($data!=='') $_SESSION['linked_data'][]=$data;
}
if(isset($_POST['hapus'])){
    $index=(int)($_POST['index']??-1);
    if($index>=0 && $index<count($_SESSION['linked_data'])) array_splice($_SESSION['linked_data'],$index,1);
}
if(isset($_POST['reset'])) $_SESSION['linked_data']=["Node 1","Node 2","Node 3"];
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Linked List</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<a href="index.php" class="back">← Kembali</a>
<h1>Struktur Data Linked List</h1>
<p>Linked List terdiri dari node yang saling terhubung.</p>
<form method="post" class="form">
<input type="text" name="data" placeholder="Masukkan data..." required>
<button type="submit" name="tambah">Tambah Node</button>
<button type="submit" name="reset" class="danger">Reset</button>
</form>
<h2>Rangkaian Node</h2>
<div class="linked">
<?php foreach($_SESSION['linked_data'] as $index=>$item): ?>
<div class="node"><strong>Node <?= $index+1 ?></strong><span><?= htmlspecialchars($item) ?></span>
<form method="post"><input type="hidden" name="index" value="<?= $index ?>"><button type="submit" name="hapus" class="danger">Hapus</button></form>
</div>
<?php if($index<count($_SESSION['linked_data'])-1): ?><div class="arrow">→</div><?php endif; ?>
<?php endforeach; ?>
</div>
<div class="info"><h3>Cara Kerja</h3><p>Setiap node secara konsep menyimpan data dan referensi menuju node berikutnya.</p></div>
</div></body></html>